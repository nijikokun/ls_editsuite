<html>
<head>
<title>WeBringYouGaming - LocalShops Config Generator</title>
</head>
<body>
<center><h2>WeBringYouGaming - Generate a new shop</h2><br />
<form method="post" action="shops/generator.php">
<label for="file">Shop name:</label> <input type="text" name="file" id="file"><br />
<label for="world">World:</label> <br /><input type="text" name="world" id="world"><br /><br />
<label for="owner">Shop Owner:</label> <br /><input type="text" name="owner" id="owner"><br />
<label for="managers">Shop Managers:</label> <br /><input type="text" name="managers" id="managers"><br />
<label for="creator">Creator (optional):</label> <br /><input type="text" name="creator" id="creator"><br /><br />
<label for="position1">Shop Position 1:</label> <br /><input type="text" name="position1" id="position1"><br />
<label for="position2">Shop Position 2:</label> <br /><input type="text" name="position2" id="position2"><br /><br />
<label for="money">Unlimited Money:</label><br /><input type="radio" name="money" value="true">Yes<br />
<input type="radio" name="money" value="false">No<br />
<label for="nostock">Unlimited Stock:</label><br /><input type="radio" name="nostock" value="true">Yes<br />
<input type="radio" name="nostock" value="false">No<br />
<input type="Submit" value="Generate"></form><br /><br />
<h4>LocalShops Shop Suite (c) iffa 2011 - LocalShops made by Mineral, cereal and Jonbas</h4></center>

</body>
</html>
