<html>
<head>
<title>WeBringYouGaming - LocalShops Shop Editor</title>
</head>
<body>
<center><h2>WeBringYouGaming - Shop Editor</h2><br />
<form method="post" action="shops/generator2.php">
<label for="shop">Shop UUID (file name excluding .shop):</label> <br /><input type="text" name="shop" id="shop"><br /><br />
<label for="item">Item ID:</label> <br /><input type="text" name="item" id="item"><br />
<label for="dataval">Data value (subtype):</label> <br /><input type="text" name="dataval" id="dataval"><br /><br />
<label for="buyprice">Buy Price:<br /><input type="text" name="buyprice" id="buyprice"><br />
<label for="bundlebuy">Bundle Size:<br /><input type="text" name="bundlebuy" id="bundlebuy"><br /><br />
<label for="sellprice">Sell Price:<br /><input type="text" name="sellprice" id="sellprice"><br />
<label for="bundlesell">Bundle Size:<br /><input type="text" name="bundlesell" id="bundlesell"><br /><br />
<label for="stock">Stock: <br /><input type="text" name="stock" id="stock"><br />
<input type="Submit" value="Add Item"></form><br /><br />
<h4>LocalShops Shop Suite (c) iffa 2011 - LocalShops made by Mineral, cereal and Jonbas</h4></center>
</body>
</html>
