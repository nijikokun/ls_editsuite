<html>
<head>
<title>WeBringYouGaming - LocalShops Shop Suite</title>
</head>
<body>
<center><h2>WeBringYouGaming - LocalShops Shop Suite</h2><br /><br />
<h2><a href=generate.php>Make a new shop</a></h2><br />
<h3>Generate a new shop with the settings you give<br /><br />
<h2><a href=additem.php>Edit a shop</a></h2><br />
<h3>Edit uploaded/generated shops' settings or add new items to the shop<br /><br />
<h2><a href=upload.php>Upload a shop</a></h2><br />
<h3>Upload existing shops from your server to the generator<br /><br />
<h4>LocalShops Shop Suite (c) iffa 2011 - LocalShops made by Mineral, cereal and Jonbas</h4></center>
</body>
</html>
